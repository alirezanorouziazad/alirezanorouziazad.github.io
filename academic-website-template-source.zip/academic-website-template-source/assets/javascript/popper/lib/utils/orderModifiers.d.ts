import type { Modifier } from "../types";
export default function orderModifiers(modifiers: Array<Modifier<any, any>>): Array<Modifier<any, any>>;
