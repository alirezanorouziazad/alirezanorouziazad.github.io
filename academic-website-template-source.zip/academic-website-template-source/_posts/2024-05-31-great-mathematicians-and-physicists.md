---
layout: post
title: "Great Mathematicians and Physicists"
date: 2024-05-31
categories: "Fun"
---

A list of 50 brilliant minds who have significantly advanced our understanding of the world and contributed to making it a better place!

{% include csv_to_table.html dataset=site.data.great_mathematicians_and_physicists %}
