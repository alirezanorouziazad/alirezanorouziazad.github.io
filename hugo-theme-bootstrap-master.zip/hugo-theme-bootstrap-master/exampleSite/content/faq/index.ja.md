+++
title = "よくある質問"
layout = "faq"
comment = false
[menu.main]
  parent = "support"
  weight = 6
  [menu.main.params]
    icon = '<i class="fas fa-question-circle fa-fw text-info"></i>'
[menu.footer]
  parent = "support"
  weight = 6
  [menu.footer.params]
    icon = '<i class="fas fa-fw fa-question-circle"></i>'
+++
