---
title: Hugoの著者
description: Hugoは、最も人気のあるオープンソースの静的サイトジェネレータの1つです。驚異的なスピードと柔軟性で、Hugoはウェブサイトを作る楽しみを再び与えてくれます。
social:
  github: gohugoio
  twitter: GoHugoIO
  website: https://gohugo.io/
---
