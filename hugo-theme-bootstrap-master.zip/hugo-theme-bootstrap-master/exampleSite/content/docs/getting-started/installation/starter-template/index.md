+++
title = "Starter Template"
redirect = "https://github.com/razonyang/hugo-theme-bootstrap-skeleton"
navWeight = 100
date = 2021-12-16T17:25:20+08:00
+++

The starter template for newbie.
