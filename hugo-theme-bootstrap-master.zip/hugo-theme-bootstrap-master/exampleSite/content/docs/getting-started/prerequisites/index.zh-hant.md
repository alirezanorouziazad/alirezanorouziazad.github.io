+++
# type = "docs"
title = "先決條件"
date = 2022-06-13T16:32:09+08:00
# description = "" # Used by description meta tag, summary will be used instead if not set or empty.
featured = false
draft = false
comment = true
toc = true
reward = true
pinned = false
carousel = false
categories = []
tags = ["先決條件"]
series = ["文檔"]
images = []
navWeight = 90
authors = ["RazonYang"]
+++

在安裝主題前，請確保你滿足先決條件。

<!--more-->

## Configuration

HBS 要求設置以下配置。

{{< code-toggle filename="config" >}}
{{% config/build-write-stat %}}
{{</ code-toggle >}}

## 構建工具

{{% code/prerequisites-build-tools %}}

> 我們建議使用這些工具的最新版本。
