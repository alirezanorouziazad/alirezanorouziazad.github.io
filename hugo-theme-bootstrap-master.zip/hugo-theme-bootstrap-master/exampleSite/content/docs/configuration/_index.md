+++
title = "Configuration"
linkTitleIcon = '<i class="fas fa-cog fa-fw"></i>'
navWeight = 980
[menu.footer]
  parent = "docs"
  weight = 2
  [menu.footer.params]
    icon = '<i class="fas fa-cog fa-fw"></i>'
+++
