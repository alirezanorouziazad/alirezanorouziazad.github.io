+++
title = "Widgets"
linkTitleIcon = '<i class="fas fa-cubes fa-fw" style="color: blue;"></i>'
aliases = [
  "/en/posts/widgets"
]
navWeight = 700
+++
