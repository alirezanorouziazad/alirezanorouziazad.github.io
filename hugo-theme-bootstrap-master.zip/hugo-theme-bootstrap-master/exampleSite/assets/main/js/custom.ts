console.log("message from assets/main/js/custom.ts");
