import Component from "js/component";

const components: Component[] = [];

export default components;
