import Mermaid from "mermaid";
import options from "./options";

Mermaid.initialize(options);
