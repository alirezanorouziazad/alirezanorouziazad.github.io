import ModeToggle from "js/mode";
import PaletteSelector from "js/palettes";

new ModeToggle().run();
new PaletteSelector().run();
